package com.mj;

public class Constants {
    public static final int PORT = 8888;
}
